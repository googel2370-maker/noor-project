import Foundation

struct AppConfig {
    static let serverBase = "https://your-server.example.com" // change to your server
    static let openAIModel = "gpt-4o-mini"
}
